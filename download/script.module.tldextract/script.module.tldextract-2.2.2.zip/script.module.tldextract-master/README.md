# script.module.tldextract
Accurately separate the TLD from the registered domain and subdomains of a URL, using the Public Suffix List. 
