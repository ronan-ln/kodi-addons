"""Export tldextract's public interface."""

from .tldextract import extract, TLDExtract
