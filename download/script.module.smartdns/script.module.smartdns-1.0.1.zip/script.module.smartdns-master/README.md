# script.module.smartdns
Scripts for using Smart DNS with python requests
