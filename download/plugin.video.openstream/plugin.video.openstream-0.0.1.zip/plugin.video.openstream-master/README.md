# plugin.video.openstream
Simple Kodi add on which allows to input a stream URL to open
