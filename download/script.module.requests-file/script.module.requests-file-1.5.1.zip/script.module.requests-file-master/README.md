# script.module.requests-file
Transport adapter for fetching file:// URLs with the requests python library 
